num=4
num*=2
num1=num+2
num1+=3
print(num1)
