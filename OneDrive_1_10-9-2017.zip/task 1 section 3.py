print ("This program will add 2 different numbers and will find the results")
#define numbers as integer
number1 = int(input("please enter the first number"))
number2 = int(input("please enter the second number"))
print ("thank you")
#now I will define the results by just adding '+' the numbers together
result = number1 + number2
print ("the result is")
print (result)


